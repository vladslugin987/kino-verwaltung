document.addEventListener('DOMContentLoaded', () => {
  const app = document.querySelector('#app');
  if (app) app.textContent = 'Hello World';
});
